/**
 * Menentukan jumlah visitor untuk setiap variant A/B testing
 * 
 * ketentuan input: input adalah angka dan wajib lebih dari 0
 * 
 * (Akan di dijelaskan case penggunaannyaa & sedikit penjelasan looping)
 * 
 * Tips: 
 * - pembulatan ke bawah : Math.floor(angkanya)
 * - pembulatan ke atas : Math.ceil(angkanya)
 */

/**
 * Example input & output:
 * 
 * input:
 * totalVariant = 3
 * targetVisitor = 8
 * 
 * output:
 * Variant ke-1 akan mendapatkan 3 visitor
 * Variant ke-2 akan mendapatkan 3 visitor
 * Variant ke-3 akan mendapatkan 2 visitor
 * 
 * -----------------------------------------
 * 
 * input:
 * totalVariant = 3
 * targetVisitor = 2
 * 
 * output:
 * Variant ke-1 akan mendapatkan 1 visitor
 * Variant ke-2 akan mendapatkan 1 visitor
 * Variant ke-3 akan mendapatkan 0 visitor
 * 
 */

/*
const prompt = require('prompt-sync')();

let totalVariant = prompt('Ada berapa variant? ');
totalVariant = parseInt(totalVariant);

let targetVisitor = prompt('Target/Total visitor untuk pengujian A/B testing? ');
targetVisitor = parseInt(targetVisitor);

// start, kondisi (kondisi masih true, jalankan yg dalem { } ), setelah loop selesai ubah nilai i
for (let i = 1; i <= totalVariant; i++) {


  // (start) lengkapi kode ini:

  let visitor = // ...;

  // (end) lengkapi kode ini:

  
  console.log(`Variant ke-${i} akan mendapatkan ${visitor} visitor`);
}
*/

// yohanes
/*

const prompt = require('prompt-sync')();
let totalVariant = prompt('Ada berapa variant? ');
totalVariant = parseInt(totalVariant);

let targetVisitor = prompt('Target/Total visitor untuk pengujian A/B testing? ');
targetVisitor = parseInt(targetVisitor);

let pengunjungawal = Math.floor (targetVisitor / totalVariant); // bagi rata, ex : visitor = 10 & variant = 3, maka = 3
let sisaPengunjung = targetVisitor - (pengunjungawal * totalVariant); // targetVisitor % totalVariant; // 

// sisa = 2 => variant 1 sampai 2

for (let i = 1; i <= totalVariant; i++) {
  let visitor = pengunjungawal;

  // if(i <= sisaPengunjung) {
  //   visitor += 1;
  // }
  if (sisaPengunjung > 0) {
    visitor++;
    sisaPengunjung--;
  }

  console.log(`Variant ke-${i} akan mendapatkan ${visitor} visitor`);
}
*/

// orlando
/*
let hasilBagi = Math.floor(targetVisitor / totalVariant);
let sisaBagi = targetVisitor % totalVariant;
for (let i = 1; i <= totalVariant; i++) {
  let visitor = hasilBagi;
  if (i <= sisaBagi) {
    visitor += 1; 
  }
  console.log(`Variant ke-${i} akan mendapatkan ${visitor} visitor`);
}
*/


// darryl

/*

const prompt = require('prompt-sync')();
let totalVariant, targetVisitor;

totalVariant = parseInt(prompt('Ada berapa variant? '));
targetVisitor = parseInt(prompt('Jumlah Visitor '));

console.log(`Total pengunjung: ${targetVisitor}`);
if (totalVariant === 0) {
    console.log('Tidak ada varian yang tersedia.');
} else {
    console.log(`Pengunjung akan dibagi di antara ${totalVariant} varian.`);
    let visitorPerVariant = Math.floor(targetVisitor / totalVariant),
        remainingVisitor = targetVisitor % totalVariant;
    for (let i = 1; i <= totalVariant; i++) {
        let visitor = visitorPerVariant + (i <= remainingVisitor ? 1 : 0);
        console.log(`Variant ke-${i} akan mendapatkan ${visitor} visitor`);
    }
}

*/

// ihwan

const prompt = require('prompt-sync')();

let totalVariant = prompt('Ada berapa variant? ');
totalVariant = parseInt(totalVariant);

let targetVisitor = prompt('Target/Total visitor untuk pengujian A/B testing? ');
targetVisitor = parseInt(targetVisitor);

for (let i = 1; i <= totalVariant; i++) { //selama i kurang dari inputan totalVariant, kondisi dibawah ini akan terus di eksekusi. dan jika masih memenuhi, maka i ditambah 1

  bulatAtas = Math.ceil(targetVisitor / totalVariant); //membulatkan bilangan keatas      4
  bulatBawah = Math.floor(targetVisitor / totalVariant); //membulatkan bilangan kebawah   3

  console.log({i, bulatAtas, bulatBawah}); 

  if (i + (totalVariant * bulatBawah) <= targetVisitor) { //katakanlah(1 + 4 * 2) <= 10 
    visitor = bulatAtas; //visitor menyimpan nilai bulatAtas
  } else {
    visitor = bulatBawah; //visitor menyimpan nilai bulatBawah
  }

  console.log(`Variant ke-${i} akan mendapatkan ${visitor} visitor`);
}