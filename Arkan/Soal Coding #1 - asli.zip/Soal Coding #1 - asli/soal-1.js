/**
 * Menghitung luas belah ketupat
 */

/**
 * function = melakukan suatu proses
 * - "proses" di dalem function bisa menghasilkan "sesuatu" ==>  (return)
 * - "proses" yg dilakuin, terkadang perlu sautu "bahan" (parameter/argumen function)
 * 
 * masak mie adalah suatu function
 * - peralatan & bahan ==> parameter
 * - mie nya jadi ==> return
 */


let diagonal1 = 10;
let diagonal2 = 20;


// (start) lengkapi kode ini:

// let luas = (diagonal1 * diagonal2) / 2;    

// * 1/2

// let luas = 0.5 * diagonal1 * diagonal2;

// let luas = 1/2 * diagonal1*diagonal2;


function luasBelahKetupat(diagonal1, diagonal2){
    return 0.5 * diagonal1 * diagonal2;
}


// (end) lengkapi kode ini:


let luas_1 = luasBelahKetupat(diagonal1, diagonal2);
console.log(luas_1); // expected output: 100


let luas_2 = luasBelahKetupat(70, 50);
console.log(luas_2); // expected output: 1750