/**
 * Menghitung luas trapesium
 */


let sisiAtas = 10;
let sisiBawah = 20;
let tinggi = 7;


// (start) lengkapi kode ini:

let luas = (sisiAtas + sisiBawah) * tinggi / 2;

// (end) lengkapi kode ini:


console.log(luas); // expected output: 105