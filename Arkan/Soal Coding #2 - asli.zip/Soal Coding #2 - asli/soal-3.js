/**
 * Penjumlahan
 * 
 * Ketentuan:
 * - jika input adalah angka, maka jumlahkan dengan angka-angka sebelumnya
 * - jika input bukan angka, misal "=" atau apapun itu, outputkan hasil penjumlahannya
 * 
 * tips: dapat menggunakan regular expression (regex) untuk mengecek apakah input adalah angka
 * input.match(/^\d+$/)
 */


// rafli

const prompt = require('prompt-sync')();

// let jumlah = 0;
// let input;

// while ((input = prompt('input ? ')) !== '=') {
//   if (input.match(/^\d+$/)) {
//     jumlah += parseInt(input);
//   } else {
//     console.log(`Input tidak valid: ${input}`);
//   }
// }

// console.log(`Jumlah = ${jumlah}`);

// ihwan

// const prompt = require('prompt-sync')();
// let jumlah = 0;

// for (let i = 0; 0 <= i; i++) {
//     const input = prompt('input? ');

//     if (input.match(/^\d+$/)) {
//         jumlah += parseInt(input);
//     } else {
//         console.log(`jumlah = ${jumlah}`);
//         break;
//     }
// }

// orlando

// let jumlah = 0;
// for (i = 0; (i) => 5; i++) {
//   const input = prompt("input ? ");
//   if (input.match(/^\d+$/)) {
//     jumlah += parseInt(input);
//   } else {
//     console.log(`jumlah = ${jumlah} `); // ini diganti dengan jumlah seluruh inputnya
//     break;
//   }
// }

// teddy

// const prompt = require('prompt-sync')();

// let sum = 0;

// while (true) {
//     const input = prompt('Input ? ');

//     if (input.match(/^\d+$/)) {

//         sum += parseInt(input);
//     } else {
        
//         console.log('Jumlah = ' + sum);
//         break;
//     }
// }

// darryl

// const prompt = require('prompt-sync')();
function calculateTotal() {
    const input = prompt('Input? ');
    if (input.match(/^\d+$/)) {
        return parseInt(input) + calculateTotal();
    } else {
        return 0;
    }
}
const total = calculateTotal(); // 10 + (5 + (7 + (0) ))
console.log('Jumlah =', total);