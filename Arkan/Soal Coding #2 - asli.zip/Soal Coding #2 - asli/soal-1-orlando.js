for (let i = 0; i < menus.length; i++) {
  if (role == "administrator") {
    console.log(menus[i]);
  }
}
for (let j of [0, 1, 4]) {
  if (role == "member") {
    console.log(menus[j]);
  }
}
for (let x = 0; x < menus.length - 2; x++) {
  if (role == "admin") {
    console.log(menus[x]);
  }
}

/**
 * loop all menu
 *  - tiap menu, dicek rolenya, apakah muncul/disembunyikan
 *    - apabila dimunculkan, maka menunya munculkan
 *    - kalo engga, skip ke menu berikutnya
 */