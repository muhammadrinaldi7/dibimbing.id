// while
// let i = 11;
// while (i <= 10 ) {
//   console.log('di while, ' + i);
//   i++;
// }


// do while
let i = 11;
do {
  console.log('di do-while, ' + i);
  i++;
} while (i <= 10)


// kapan pakai do-while? kalau proses looping nya wajib dilakukan minimal 1x