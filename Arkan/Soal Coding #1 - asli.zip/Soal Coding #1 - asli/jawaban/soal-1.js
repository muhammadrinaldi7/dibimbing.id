/**
 * Menghitung luas belah ketupat
 */


let diagonal1 = 10;
let diagonal2 = 20;


// (start) lengkapi kode ini:

let luas = diagonal1 * diagonal2 / 2;

// (end) lengkapi kode ini:


console.log(luas); // expected output: 100