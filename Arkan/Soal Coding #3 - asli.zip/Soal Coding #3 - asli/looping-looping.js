
// let array = [ [1,2,3], [1,2,3] 1,2,3,5];
let count = 0;
for (let i = 1; i <= 5 ; i++) {

  for (let j = 1; j <= 5; j++) {
    console.log(`i = ${i}, j = ${j}, count = ${count}`);
    count++;
  }
  
}