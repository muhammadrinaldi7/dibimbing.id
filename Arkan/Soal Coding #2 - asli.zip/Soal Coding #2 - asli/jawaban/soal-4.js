/**
 * Penjumlahan
 * 
 * Ketentuan:
 * - jika input adalah angka, maka jumlahkan dengan angka-angka sebelumnya
 * - jika input bukan angka, misal "=" atau apapun itu, outputkan hasil penjumlahannya
 * 
 * tips: dapat menggunakan regular expression (regex) untuk mengecek apakah input adalah angka
 * input.match(/^\d+$/)
 */

const prompt = require('prompt-sync')();

let angka = []; // [9, 7, 1]  9 + 7 + 1
while (true) {
  const input = prompt('input ? ');

  // check if input is number
  if (input.match(/^\d+$/)) {
    angka.push(parseInt(input));
  }
  else {
    break;
  }
}

let jumlah = 0;
let textAngka = "";
for (let i = 0; i < angka.length; i++) {
  textAngka += (i !== angka.length - 1) ? angka[i] + " + " : angka[i];
  jumlah += angka[i];
}
if (textAngka.length === 0) {
  textAngka = "0";
}

console.log(`jumlah = ${textAngka} = ${jumlah}`);