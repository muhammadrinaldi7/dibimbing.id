/**
 * Show menu sesuai dengan "user role", ketentuan:
 * 
 * administrator:
 * - menu 1, menu 2, menu 3, menu 4, menu 5 (allowed)
 * 
 * admin:
 * - menu 1, menu 2, menu 3
 * 
 * member:
 * - menu 1, menu 2, menu 5
 */


/**
 * 1. Autentikasi   => login/tidak => user harus login (user harus terautentikasi)
 * 2. Autorisasi    => hak akses => wajib login => role user
 */

const prompt = require('prompt-sync')();

const role = prompt('Role user ? '); // user role
const menus = ["menu 1", "menu 2", "menu 3", "menu 4", "menu 5", "menu 6", "menu 7"]; // available menu

// list role & permission
const permissions = {
  administrator : ["menu 1", "menu 2", "menu 3", "menu 4", "menu 5"],
  admin: ["menu 1", "menu 2", "menu 3", "menu 6"],
  member: ["menu 1", "menu 2", "menu 5", "menu 7"]
}

// proses penampilan (ini tidak bisa dirubah)
for (let i = 0; i < menus.length; i++) {

  // check role sekarang (input) ada di list permission atau tidak?
  let showMenu = false;
  if (permissions[role]) {
    if (permissions[role].includes(menus[i])) {
      showMenu = true;
    }
  }

  if (showMenu) {
    console.log(menus[i]);
  }

}
// end proses