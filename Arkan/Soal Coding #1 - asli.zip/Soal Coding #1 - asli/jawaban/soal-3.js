/**
 * Menghitung luas lingkaran
 * 
 * Gunakan pi 22/7 jika jari-jari kelipatan 7
 * Gunakan pi 3,14 jika jari-jari bukan kelipatan 7
 */


// let jariJari = 10; // expected output : 314
let jariJari = 14; // expected output : 616


// (start) lengkapi kode ini:

let luas = jariJari % 7 === 0 ? (22/7)*jariJari*jariJari : 3.14*jariJari*jariJari;

// (end) lengkapi kode ini:


console.log(luas);