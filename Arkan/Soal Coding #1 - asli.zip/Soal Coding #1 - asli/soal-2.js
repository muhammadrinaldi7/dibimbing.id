/**
 * Menghitung luas trapesium
 */


let sisiAtas = 10;
let sisiBawah = 20;
let tinggi = 7;


// (start) lengkapi kode ini:

// let sisiSejajar = sisiAtas + sisiBawah;
// let luas = 0.5 * sisiSejajar * tinggi;

// let luas = 0.5 * (sisiAtas + sisiBawah) * tinggi;

// let luas = (sisiAtas + sisiBawah) * tinggi / 2;

// let luas = 0.5 * (sisiAtas + sisiBawah) * 7

// let luas = ((sisiAtas + sisiBawah) / 2) * tinggi;

// let luas = 0.5 * (sisiAtas + sisiBawah) * tinggi;

// function luasTrapesium(sA, sB, t){
//   return 0.5 * (sA + sB) * t;
// }

// let luas = 1/2*(sisiAtas + sisiBawah)*tinggi;

// (end) lengkapi kode ini:

// let luas = luasTrapesium(sisiAtas, sisiBawah, tinggi);
console.log(luas); // expected output: 105