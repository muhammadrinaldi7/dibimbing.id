
const prompt = require("prompt-sync")();

let sum = 0;
const num = [];

while (true) {
  const input = prompt("input ? ");
  if (input.match(/[0-9]/)) {
    sum += parseInt(input);
    num.push(input);
  } else break;
}
console.log(`jumlah = ${num.join(" + ")} = ${sum}`);

// let arrayAngka = [9,7,1];

// let text = arrayAngka.join(' + ');
// console.log(text);