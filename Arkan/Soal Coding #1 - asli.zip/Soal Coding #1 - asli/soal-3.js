/**
 * Menghitung luas lingkaran
 * 
 * pi 
 * kalau kelipatan 7 pake yg 22/7
 * kalau bukan pake yg 3.14
 * 
 * luas lingkaran = 3.14 * r * r
 */


// let jariJari = 10; // expected output : 314
// let jariJari = 14; // expected output : 616

let jariJari = 100;



// (start) lengkapi kode ini:

// const pi = Math.PI;
// let luas = pi * (jariJari ** 2);

// const pi = Math.PI;
// let luas = Math.round(pi * Math.pow(jariJari, 2));

// let luas = 0;
// if (jariJari % 7 === 0) {
//   luas = (22 / 7) * jariJari * jariJari;//Math.pow(jariJari, 2);
// } else {
//   luas = 3.14 * Math.pow(jariJari, 2);
// }

// if (jariJari == 10) {
//   let luas = 3.14 * jariJari * jariJari;
//   console.log(luas);
// } else if (jariJari == 14) {
//   let luas = (22 / 7) * jariJari * jariJari;
//   console.log(luas);
// }

function luasLingkaran(jariJari) {

  // default value (value awal)
  let luas = 0;

  // proses
  if (jariJari % 7 === 0) {
    luas = (22 / 7) * jariJari * jariJari;//Math.pow(jariJari, 2);
  } else {
    luas = 3.14 * Math.pow(jariJari, 2);
  }

  // return
  return luas;
}

// (end) lengkapi kode ini:

let luas = luasLingkaran(jariJari);
console.log(luas);