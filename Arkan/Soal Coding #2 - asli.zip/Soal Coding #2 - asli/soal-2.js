/**
 * counter "yes"
 * 
 * input terminal adalah "yes" / "no"
 * 
 * output adalah angka dari berapa kali jumlah "yes"
 * 
 * tips: ini menggunakan infinity looping & break
 */

const prompt = require('prompt-sync')();

// const input = prompt('continue (yes) / berhenti (no) ? ');

// console.log(`Anda menginput "yes" sebanyak x kali`);


// const prompt = require('prompt-sync')();

// for (let i = 0; 0 <= i; i++) {
//     const input = prompt('continue (yes) / berhenti (no) ? ');

//     if (input === 'no') {
//         console.log(`Anda menginput "yes" sebanyak ${i} kali`);
//         break;
//     }
// }

// const prompt = require('prompt-sync')();

// let totalYes = 0;

// while (true) {
//     const input = prompt('continue (yes) / berhenti (no) ? ');

//     if (input.toLowerCase() === 'yes') {
//         totalYes++;
//     } else {
//         break;
//     }
// }

// console.log(`Anda menginput "yes" sebanyak ${totalYes} kali.`);

// const prompt = require("prompt-sync")();
// for (let i = 0; true; i++) {
//   const input = prompt("continue (yes) / berhenti (no) ? ");
//   if (input == "no") {
//     console.log(`Anda menginput "yes" sebanyak ${i} kali`);
//     break;
//   }
// }

// const prompt = require("prompt-sync")();

let count = 0;

do {
  const input = prompt("continue (yes) / berhenti (no) ? ");
  if (input === "no") break;
  count++;
} while (true);

console.log(`Anda menginput "yes" sebanyak ${count} kali`);